#include "mamifero.h"



mamifero::~mamifero()
{
    //dtor
}

