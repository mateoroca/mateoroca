#include "oviparo.h"
#include <iostream>

using namespace std;

oviparo::oviparo()
{
    //ctor
}

oviparo::~oviparo()
{
    //dtor
}


